import ActivityList from "../components/Activity/ActivityList";

export default function ActivityPage() {
  return <ActivityList />;
}