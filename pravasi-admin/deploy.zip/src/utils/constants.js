// export const BASE_URL =
//   import.meta.env.VITE_API_BASE_URL || "http://pravasi-backend-env.eba-myxwcnwj.ap-south-1.elasticbeanstalk.com/api";
// export const IMAGE_BASE_URL = import.meta.env.VITE_IMAGE_BASE_URL || "http://pravasi-backend-env.eba-myxwcnwj.ap-south-1.elasticbeanstalk.com";

export const BASE_URL =
  import.meta.env.VITE_API_BASE_URL || "http://pravasi-backend-env.eba-myxwcnwj.ap-south-1.elasticbeanstalk.com/api";
export const IMAGE_BASE_URL = import.meta.env.VITE_IMAGE_BASE_URL || "http://pravasi-backend-env.eba-myxwcnwj.ap-south-1.elasticbeanstalk.com";

