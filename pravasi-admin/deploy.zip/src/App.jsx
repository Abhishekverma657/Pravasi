// // // import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// // // import HeroSlider from "./pages/HeroSlider";
// // // import MissionPage from "./pages/MissionPage";
// // // import Sidebar from "./components/Sidebar";
// // // import { useState } from "react";

// // // function App() {
// // //   const [collapsed, setCollapsed] = useState(true);

// // //   return (
// // //     <Router>
// // //       <div className="flex min-h-screen bg-gray-100">
// // //         <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />
// // //         <div
// // //           className={`flex-1 p-4 transition-all duration-300 ${
// // //             // md:ml-56 means margin-left on desktop, 0 on mobile
// // //             "md:ml-56"
// // //           }`}
// // //         >
// // //           <Routes>
// // //             <Route path="/" element={<HeroSlider />} />
// // //             <Route path="/hero-slider" element={<HeroSlider />} />
// // //             <Route path="/mission" element={<MissionPage />} />
// // //           </Routes>
// // //         </div>
// // //       </div>
// // //     </Router>
// // //   );
// // // }

// // // export default App;

// // import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// // import { useState } from "react";
// // import Sidebar from "./components/Sidebar";
// // import HeroSlider from "./pages/HeroSlider";
// // import MissionPage from "./pages/MissionPage";

// // function App() {
// //   const [collapsed, setCollapsed] = useState(true);

// //   return (
// //     <Router>
// //       <div className="flex min-h-screen bg-gray-100">
// //         {/* Sidebar */}
// //         <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />

// //         {/* Page Content */}
// //         <div
// //           className={`
// //             flex-1 p-1 transition-all duration-300
// //             md:ml-0            /* desktop left margin for sidebar */
// //             ${collapsed ? "ml-0" : ""}
// //           `}
// //         >
// //           <Routes>
// //             <Route path="/" element={<HeroSlider />} />
// //             <Route path="/hero-slider" element={<HeroSlider />} />
// //             <Route path="/mission" element={<MissionPage />} />
// //           </Routes>
// //         </div>
// //       </div>
// //     </Router>
// //   );
// // }

// // export default App;

// import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// import { useState } from "react";
// import Sidebar from "./components/Sidebar";
// import HeroSlider from "./pages/HeroSlider";
// import MissionPage from "./pages/MissionPage";
// import PeoplePage from "./pages/PeoplePage";
// import FeaturedEventsPage from "./pages/FeaturedEventsPage";
// import BenefitsPage from "./pages/BenefitsPage";
// import NewsPage from "./pages/NewsPage";
// import GalleryPage from "./pages/GalleryPage";
// import MediaBlogs from "./pages/MediaBlogs";
// import Contact from "./pages/Contact";
// import FAQ from "./pages/FAQ";   
// import DashboardPage from "./pages/DashboardPage";
// import MyuzeSubscription from "./components/MyuzeSubscription";
// import BusinessPage from "./pages/Business";
// import OurRoot from "./pages/OurRootPage";
// import Advertise from "./pages/AdvertisePage";
 


// function App() {
//   const [collapsed, setCollapsed] = useState(true);

//   return (
//     <Router>
//       <div className="flex min-h-screen bg-gray-100 overflow-hidden">
//         {/* Sidebar */}
//         <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />

//         {/* Page Content */}
//         <div
//           className={`
//             flex-1 transition-all duration-300
//             ${collapsed ? "ml-0" : "ml-56"} 
//             overflow-y-auto h-screen
//             p-4
//           `}
//         >
//           <Routes>
//             <Route path="/" element={<DashboardPage />} />
//             <Route path="/dashboard" element={<DashboardPage />} />
//             <Route path="/hero-slider" element={<HeroSlider />} />
//             <Route path="/mission" element={<MissionPage />} />
//             <Route path="/people" element={<PeoplePage />} />
//              <Route path="/featured-events" element={<FeaturedEventsPage />} />
            
//             <Route path="/benefits" element={<BenefitsPage />} />
            
//             <Route path="/news" element={<NewsPage />} />
//             <Route path="/gallery" element={<GalleryPage />} />
           
//             <Route path="/media-blogs" element={<MediaBlogs />} />
           
//             <Route path="/contact" element={<Contact />} />
//             <Route path="/our-root" element={<OurRoot />} />
//             <Route path="/advertise" element={<Advertise />} />
            

//             <Route path="/faq" element={<FAQ />} />
//             <Route path="/business" element={<BusinessPage />} />

//             {/* <Route path="/myuze-subscription" element={<MyuzeSubscription />} /> */}
           




             
//           </Routes>
        
//         </div>
//       </div>
//     </Router>
//   );
// }

// export default App;

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { useState } from "react";
import Sidebar from "./components/Sidebar";
import HeroSlider from "./pages/HeroSlider";
import MissionPage from "./pages/MissionPage";
import PeoplePage from "./pages/PeoplePage";
import FeaturedEventsPage from "./pages/FeaturedEventsPage";
import BenefitsPage from "./pages/BenefitsPage";
import NewsPage from "./pages/NewsPage";
import GalleryPage from "./pages/GalleryPage";
import MediaBlogs from "./pages/MediaBlogs";
import Contact from "./pages/Contact";
import FAQ from "./pages/FAQ";
import DashboardPage from "./pages/DashboardPage";
import BusinessPage from "./pages/Business";
import OurRoot from "./pages/OurRootPage";
import Advertise from "./pages/AdvertisePage";
import LoginPage from "./pages/LoginPage";
import ProtectedRoute from "./components/ProtectedRoute";
import { AuthProvider } from "./context/AuthContext";
import NotificationList from "./components/notifications/NotificationList";
import NotificationPage from "./pages/NotificationPage";
import ChaptersPage from "./pages/ChaptersPage";
import About from "./pages/About";
import ActivityPage from "./pages/ActivityPage";
import SambalYojna from "./pages/SambalYojna";
import ChangePassword from "./pages/changePassword";

function App() {
  const [collapsed, setCollapsed] = useState(true);

  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Login Route */}
          <Route path="/login" element={<LoginPage />} />

          {/* Protected routes */}
          <Route element={<ProtectedRoute />}>
            <Route
              path="/*"
              element={
                <div className="flex min-h-screen bg-gray-100 overflow-hidden">
                  {/* Sidebar */}
                  <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />

                  {/* Page Content */}
                  <div
                    className={`flex-1 transition-all duration-300 ${
                      collapsed ? "ml-0" : "ml-56"
                    } overflow-y-auto h-screen p-4`}
                  >
                    <Routes>
                      <Route path="/" element={<DashboardPage />} />
                      <Route path="/dashboard" element={<DashboardPage />} />
                      <Route path="/hero-slider" element={<HeroSlider />} />
                      <Route path="/mission" element={<MissionPage />} />
                      <Route path="/people" element={<PeoplePage />} />
                      <Route
                        path="/featured-events"
                        element={<FeaturedEventsPage />}
                      />
                      <Route path="/benefits" element={<BenefitsPage />} />
                      <Route path="/news" element={<NewsPage />} />
                      <Route path="/gallery" element={<GalleryPage />} />
                      <Route path="/media-blogs" element={<MediaBlogs />} />
                      <Route path="/contact" element={<Contact />} />
                      <Route path="/our-root" element={<OurRoot />} />
                      <Route path="/advertise" element={<Advertise />} />
                      <Route path="/faq" element={<FAQ />} />
                      <Route path="/about" element={<About />} />
                      <Route path="/business" element={<BusinessPage />} />
                      <Route path="/notifications" element={<NotificationPage />} />
                      <Route path="/chapters/*" element={<ChaptersPage/>} />
                      <Route path="/activity" element={<ActivityPage/>}></Route>
                      <Route path="/sambal-yojna" element={<SambalYojna/>}></Route>
                      <Route path="/change-password" element={<ChangePassword/>}></Route>

                    </Routes>
                  </div>
                </div>
              }
            />
          </Route>
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
